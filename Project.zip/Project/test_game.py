# Vannah Tam
# Feb 23, 2026
# Tileset


import random
import arcade
import pyglet
from pyglet.math import Vec2

SPRITE_SCALING_PLAYER = 7
SPRITE_SCALING_HOTBAR = 1.5

SCREEN_WIDTH = 1680
SCREEN_HEIGHT = 1050

MOVE_SPEED = 6

CAMERA_SPEED = 1

TILE_SCALING = 4

TIME_LIMIT = 30.0

MAP_HEIGHT = 50



class MyGame(arcade.Window):
    """ Our custom Window Class"""
    
    def __init__(self):
        """Initializer"""
        # Call the parent class initializer
        super().__init__(SCREEN_WIDTH, SCREEN_HEIGHT, "Test game")
        
        # Set location of window on screen
        self.set_location(0,0)
        
        self.set_mouse_visible(False)
        
        # Variables that will have sprite lists
        self.player_list = None
        self.wall_list = None
        self.bookcase_list = None
        self.hotbar_sprite_list = None
        self.used_fire = False
        self.fire_list = None
        self.small_pud_list = None
        self.cursor_sprite = None
        self.restart_sprite = None

        #setup hotbar
        self.hotbar = ["hand", "mop", "bucket", "torch" , "shovel"]
        self.unselected_colour = (20, 20, 20)
        self.selected_colour = (230,190,10)
        self.current_item = 0
        
        # Set up the player info
        self.player_sprite = None
        self.setup()
        
        self.bucket = None
        
        self.physics_engine = None
        
        self.camera_sprites = arcade.Camera(SCREEN_WIDTH, SCREEN_HEIGHT)
        self.camera_gui = arcade.Camera(SCREEN_WIDTH, SCREEN_HEIGHT)
        
        self.mouse_x = 0
        self.mouse_y = 0       

    def setup(self):
        """Set up the game and initialize the variables. """
        
        self.lost_game = False
        self.used_fire = False
        self.time_left = TIME_LIMIT
        self.fire_spread_time = 0
        # Sprite lists
        self.player_list = arcade.SpriteList()
        self.player_sprite = arcade.AnimatedTimeBasedSprite()
        
        texture = arcade.load_texture("data\sprites\sprite.png", x = 0, y = 0, width = 32, height = 32)
        anim = arcade.AnimationKeyframe(1, 10, texture)
        self.player_sprite.frames.append(anim)
        
        # Set up the player
        self.player_sprite.center_x = 50
        self.player_sprite.center_y = 300
        self.player_sprite.width = 32
        self.player_sprite.height = 32
        self.player_sprite.scale = SPRITE_SCALING_PLAYER
        self.player_list.append(self.player_sprite)
        
        self.water_level = 0        
        
        map_name = "data/project_work/test_hexagon.tmj"
        
        # Read in the tiled map
        self.tile_map = arcade.load_tilemap(map_name, scaling=TILE_SCALING)
        
        # Set wall SpriteList and any others that you have.
        self.puddle_list = self.tile_map.sprite_lists["Puddle"]
        self.wall_list = self.tile_map.sprite_lists["Wall"]
        self.bookcase_list = self.tile_map.sprite_lists["Floor"]
        
        self.cursor_sprite = arcade.Sprite()
        
        self.cursor_textures = arcade.load_spritesheet("data/sprites/cursor.png", sprite_width = 32, sprite_height = 32, columns = 5, count = 5)
        
        self.cursor_sprite.texture = self.cursor_textures[0]
        
        self.wall_coords = []
        self.wall_tiles = []

        for wall in self.wall_list:
            self.wall_coords.append(wall.position)
        
        for bookcase in self.bookcase_list:
            self.wall_coords.append(bookcase.position)
        
        for tile in self.wall_coords:
            self.wall_tiles.append(self.pixel_to_tile(tile[0], tile[1], 32 * TILE_SCALING , 32 * TILE_SCALING , MAP_HEIGHT))
        
        self.puddle_coords = {}
        
        for puddle in self.puddle_list:
            self.puddle_coords[puddle] = [puddle.position, self.pixel_to_tile(puddle.position[0], puddle.position[1], 32 * TILE_SCALING , 32 * TILE_SCALING , MAP_HEIGHT)]
        
        #for puddle in self.puddle_coords:
            #self.puddle_tiles.append(self.pixel_to_tile(puddle[0], puddle[1], 32 * TILE_SCALING , 32 * TILE_SCALING , MAP_HEIGHT))

        self.tiles_on_fire = []
        
        self.initial_puddles = len(self.puddle_list)
        
        
        self.hotbar_sprite_list = arcade.SpriteList()
        hotbar_sprites = arcade.load_spritesheet("data/sprites/hotbar_items.png", sprite_width = 64, sprite_height = 64, columns = 5, count = 25)
        mop_texture = hotbar_sprites[1]
        mop = arcade.Sprite()
        mop.texture = mop_texture
        mop.scale = SPRITE_SCALING_HOTBAR
        mop.center_x = 735
        mop.center_y = 150
        self.hotbar_sprite_list.append(mop)
        
        self.bucket = arcade.Sprite()
        self.buckets_textures = [hotbar_sprites[2], hotbar_sprites[7], hotbar_sprites[12], hotbar_sprites[17], hotbar_sprites[22]]
        self.bucket.texture = self.buckets_textures[0]
        self.bucket.scale = SPRITE_SCALING_HOTBAR
        self.bucket.center_x = 840
        self.bucket.center_y = 150
        self.hotbar_sprite_list.append(self.bucket)
        
        self.torch = arcade.Sprite()
        self.torch_textures = [hotbar_sprites[3], hotbar_sprites[8]]
        self.torch.texture = self.torch_textures[0]
        self.torch.scale = SPRITE_SCALING_HOTBAR
        self.torch.center_x = 945
        self.torch.center_y = 150
        self.hotbar_sprite_list.append(self.torch)
        
        shovel_texture = hotbar_sprites[4]
        shovel = arcade.Sprite()
        shovel.texture = shovel_texture
        shovel.scale = SPRITE_SCALING_HOTBAR
        shovel.center_x = 1050
        shovel.center_y = 150
        self.hotbar_sprite_list.append(shovel)
        
        self.restart_sprite = arcade.Sprite()
        self.restart_sprite.texture = arcade.load_spritesheet("data/sprites/restart_button.png", sprite_width = 64, sprite_height = 64, columns = 1, count = 1)[0]
        self.restart_sprite.scale = 0.7
        self.restart_sprite.center_x = 1500
        self.restart_sprite.center_y = 935
        
        self.fire_list = arcade.SpriteList()
        self.fire_sprites = arcade.load_spritesheet("data/sprites/fire.png", sprite_width = 32, sprite_height = 32, columns = 4, count = 16)
        
        self.small_pud_list = arcade.SpriteList()
        self.small_pud_sprites = arcade.load_spritesheet("data/sprites/puddles.png", sprite_width = 32, sprite_height = 32, columns = 10, count = 50)
        
        self.slowed_fire_tiles = {}
        self.puddles_touching_fire = []
        self.slowed_fire_timer = {}
        
        
        # Set the background color to what is specified in the map
        if self.tile_map.background_color:
            arcade.set_background_color(self.tile_map.background_color)
            
        # Keep player from running through the wall_list layer
        self.physics_engine = arcade.PhysicsEnginePlatformer(
            self.player_sprite, self.wall_list, gravity_constant=0
        )
        
        
    def on_draw(self):
        
        # select camera to use to draw all sprites
        self.camera_sprites.use()
        
        arcade.start_render()

        self.wall_list.draw(pixelated = True)
        self.bookcase_list.draw(pixelated = True)
        self.puddle_list.draw(pixelated = True)
        self.player_list.draw(pixelated = True)
        self.fire_list.draw(pixelated = True)
        self.small_pud_list.draw(pixelated = True)
        
        # select separate camera to create GUI
        self.camera_gui.use()

        arcade.draw_rectangle_filled(SCREEN_WIDTH/2, 150, 530, 110, (200, 200, 200))
        
        arcade.draw_rectangle_filled(630 + self.current_item * 105, 150, 110, 110, self.selected_colour)
        
        for i in range(5):
            
            location = SCREEN_WIDTH/2 - 210
        
            arcade.draw_rectangle_filled(location + i*105, 150, 100, 100, self.unselected_colour)
        
        arcade.draw_text(f"Percentage of level burnt: {(len(self.tiles_on_fire)/len(self.wall_tiles) * 100):.2f}%", 30, 990, arcade.color.WHITE, 25)
        arcade.draw_text(f"Puddles Wiped: {int((self.initial_puddles - len(self.puddle_list))/4)} / {int(self.initial_puddles/4)}", 30, 930, arcade.color.WHITE, 25)
        arcade.draw_text(f"Time Left: {self.time_left:.2f} s", 1380, 980, arcade.color.WHITE, 25)
        
        arcade.draw_rectangle_filled(1560, 935, 180, 60, (10, 10, 10))
        self.restart_rect = arcade.draw_text("Restart", 1530, 920, arcade.color.WHITE, 25)
        self.restart_sprite.draw(pixelated = True)
            
        self.hotbar_sprite_list.draw(pixelated = True)
        
        self.cursor_sprite.draw(pixelated = True)
        
    def update(self, delta_time):
        """ Movement and game logic"""
        
        # Call update on all sprites
        self.player_list.update()
        self.player_list.update_animation()
        self.fire_list.update()
        self.small_pud_list.update()

        self.bucket.texture = self.buckets_textures[self.water_level]
        
        self.cursor_sprite.texture = self.cursor_textures[self.current_item]
        
        if self.used_fire:
            self.torch.texture = self.torch_textures[1]
            self.fire_spread_time -= delta_time
            self.time_left -= delta_time
        else:
            self.torch.texture = self.torch_textures[0]
        
            
        self.hotbar_sprite_list.update()
        # update physics
        self.physics_engine.update()
        
        # move screen
        self.scroll_to_player()
        
        if self.fire_spread_time <= 0:
            self.spread_fire()
                    
                    
        for puddle in self.puddles_touching_fire:
            self.slowed_fire_timer[puddle] -= delta_time
            if self.slowed_fire_timer[puddle] <= 0:
                keys = [key for key, val in self.slowed_fire_tiles.items() if val == puddle]
                for key in keys:
                    key.remove_from_sprite_lists()
                    del self.slowed_fire_tiles[key]
                    
        self.change_cursor()
        
        
        if self.time_left <= 0:
            self.lost_game = True
        
        if self.lost_game:
            self.game_over()
        
        
    def scroll_to_player(self):
        
        """Scroll the window to the player. If CAMERA_SPEED is 1, the camera will immediately move to the desire
        Anything between 0 and 1 will have the camera move to the location with pan."""
        
        position = Vec2(self.player_sprite.center_x - self.width / 2,
                        self.player_sprite.center_y - self.height / 2)
        self.camera_sprites.move_to(position, CAMERA_SPEED)  
    
    
    def on_resize(self, width, height):
        """
        Resize window
        Handle the user grabbing the edge and resizing the window.
        """
        self.camera_sprites.resize(int(width), int(height))
        self.camera_gui.resize(int(width), int(height))    
    
    
    def on_key_press(self, key, modifiers):
        """Check to see which key is being pressed and move the player in the appropriate direction"""
        
        match key:
            case arcade.key.KEY_1:
                self.current_item = 0
            
            case arcade.key.KEY_2:
                self.current_item = 1
                
            case arcade.key.KEY_3:
                self.current_item = 2
            
            case arcade.key.KEY_4:
                self.current_item = 3
                
            case arcade.key.KEY_5:
                self.current_item = 4
            
            case arcade.key.KEY_0:
                self.setup()
            
            case arcade.key.ESCAPE:
                arcade.close_window()
                
            case arcade.key.A:
                self.player_sprite.frames.clear()
                for i in range(4):
                    texture = arcade.load_texture("data\sprites\sprite.png", x = i * 32, y = 64, width = 32, height = 32)
                    anim = arcade.AnimationKeyframe(i,250,texture)
                    self.player_sprite.frames.append(anim)    
                if self.player_sprite.center_x <= 0:
                    self.player_sprite.center_x = 0
                else:
                    self.player_sprite.change_x = -MOVE_SPEED
                
            case arcade.key.D:
                self.player_sprite.frames.clear()
                for i in range(4):
                    texture = arcade.load_texture("data\sprites\sprite.png", x = i * 32, y = 96, width = 32, height = 32)
                    anim = arcade.AnimationKeyframe(i,250,texture)
                    self.player_sprite.frames.append(anim)
                    self.player_sprite.change_x = MOVE_SPEED
            
            case arcade.key.W:
                self.player_sprite.frames.clear()
                for i in range(4):
                    texture = arcade.load_texture("data\sprites\sprite.png", x = i * 32, y = 32, width = 32, height = 32)
                    anim = arcade.AnimationKeyframe(i,250,texture)
                    self.player_sprite.frames.append(anim)   
                    self.player_sprite.change_y = MOVE_SPEED
            
            case arcade.key.S:
                self.player_sprite.frames.clear()
                for i in range(4):
                    texture = arcade.load_texture("data\sprites\sprite.png", x = i * 32, y = 0, width = 32, height = 32)
                    anim = arcade.AnimationKeyframe(i,250,texture)
                    self.player_sprite.frames.append(anim)
                self.player_sprite.change_y = -MOVE_SPEED
    
    
    def on_key_release(self, key, modifiers):
        """Called whenever a user releases a key"""
        
        match key:
            case arcade.key.A:
                self.player_sprite.change_x = 0
                self.player_sprite.frames.clear()
                for i in range(4):
                    texture = arcade.load_texture("data\sprites\sprite.png", x = 0, y = 64, width = 32, height = 32)
                    anim = arcade.AnimationKeyframe(i,10,texture)
                    self.player_sprite.frames.append(anim)       
                    
            case arcade.key.D:
                self.player_sprite.change_x = 0
                self.player_sprite.frames.clear()
                for i in range(4):
                    texture = arcade.load_texture("data\sprites\sprite.png", x = 0, y = 96, width = 32, height = 32)
                    anim = arcade.AnimationKeyframe(i,10,texture)
                    self.player_sprite.frames.append(anim)                
                    
            case arcade.key.W:
                self.player_sprite.change_y = 0
                self.player_sprite.frames.clear()
                for i in range(4):
                    texture = arcade.load_texture("data\sprites\sprite.png", x = 0, y = 32, width = 32, height = 32)
                    anim = arcade.AnimationKeyframe(i,10,texture)
                    self.player_sprite.frames.append(anim)

            case arcade.key.S:
                self.player_sprite.change_y = 0
                self.player_sprite.frames.clear()
                for i in range(4):
                    texture = arcade.load_texture("data\sprites\sprite.png", x = 0, y = 0, width = 32, height = 32)
                    anim = arcade.AnimationKeyframe(i,10,texture)
                    self.player_sprite.frames.append(anim)


    def on_mouse_press(self, x, y, button, modifiers):
        """Handle mouse click events."""

        if button == arcade.MOUSE_BUTTON_LEFT:
            #clicked_tile = self.pixel_to_tile(self.world_x, self.world_y, 32 * TILE_SCALING, 32 * TILE_SCALING, MAP_HEIGHT)
            
            if self.current_item == 1:
                #colliding_puddle = arcade.check_for_collision_with_list(self.player_sprite, self.puddle_list)
                #if colliding_puddle:
                    #if self.water_level <= 3:
                        #self.water_level += 1
                    
                    #for item in colliding_puddle:
                        #item_coords = self.pixel_to_tile(item.center_x, item.center_y, 32 * TILE_SCALING , 32 * TILE_SCALING , MAP_HEIGHT)
                        #item.remove_from_sprite_lists()
                        
                        #other_puddles = []
                        #for pud in self.puddle_list: 
                            #pud_coords = self.pixel_to_tile(pud.center_x, pud.center_y, 32 * TILE_SCALING , 32 * TILE_SCALING , MAP_HEIGHT)
                            #if abs(item_coords[0] - pud_coords[0]) <= 1 and abs(item_coords[1] - pud_coords[1]) <= 1:
                                #other_puddles.append(pud)
                        
                    #for puddle in other_puddles:
                        #puddle.remove_from_sprite_lists()
                #if self.clicked_tile in self.puddle_tiles:
                    #self.puddle_coords.remove(self.puddle_coords[self.puddle_tiles.index(self.clicked_tile)])
                    #self.puddle_tiles.remove(self.clicked_tile)
                hovered_puddles = arcade.get_sprites_at_point((self.world_x,self.world_y), self.puddle_list)
                
                if hovered_puddles:
                        
                    if self.water_level <= 3:
                        self.water_level += 1
                    
                    for sprite in hovered_puddles:
                        sprite.remove_from_sprite_lists()
                        del self.puddle_coords[sprite]
                        
                    other_puddles = []
                    other_puddle_coords = {}
                    
                    for pud, coords in self.puddle_coords.items(): 
                        if abs(self.clicked_tile[0] - coords[1][0]) <= 1 and abs(self.clicked_tile[1] - coords[1][1]) <= 1 and self.clicked_tile != coords[1]:
                            other_puddles.append(pud)
                            #self.puddle_tiles.remove(self.puddle_tiles[self.puddle_coords.index(pud_coords)])
                            #self.puddle_coords.remove(pud_coords)
                            #other_puddle_coords[pud] = self.puddle_tiles.index(pud_coords)
                        
                    for puddle in other_puddles:
                        puddle.remove_from_sprite_lists()
                        del self.puddle_coords[puddle]
                else:
                    hovered_small_pud = arcade.get_sprites_at_point((self.world_x,self.world_y), self.small_pud_list)
                    if hovered_small_pud:
                        if self.water_level <= 3:
                            self.water_level += 1                            
                        for sprite in hovered_small_pud:
                            sprite.remove_from_sprite_lists()
                            del self.slowed_fire_tiles[sprite]                            


            elif self.current_item == 2 and self.water_level >= 1 and self.clicked_tile not in self.slowed_fire_tiles.values() and self.clicked_tile in self.wall_tiles:
                self.spawn_water(32 * TILE_SCALING * (self.clicked_tile[0] + 0.5) , 32 * TILE_SCALING * (MAP_HEIGHT - 0.5 - self.clicked_tile[1]))
                self.water_level -= 1
                
            elif self.current_item == 3 and self.used_fire == False and self.clicked_tile in self.wall_tiles:
                self.used_fire = True
                #clicked_sprites = arcade.get_sprites_at_point((x,y), self.bookcase_list)
                #for sprite in clicked_sprites:
                    #clicked_tile = self.pixel_to_tile(sprite.center_x, sprite.center_y, 32 * TILE_SCALING, 32 * TILE_SCALING, MAP_HEIGHT)
                if self.clicked_tile in self.wall_tiles:
                    print(f"FIRE: {self.clicked_tile}", flush = True)
                    self.spawn_fire(32 * TILE_SCALING * (self.clicked_tile[0] + 0.5) , 32 * TILE_SCALING * (MAP_HEIGHT - 0.5 - self.clicked_tile[1]))
                    self.tiles_on_fire.append(self.clicked_tile)
            
            elif self.current_item == 4:
                if self.clicked_tile in self.wall_tiles:
                    hovered_sprites = arcade.get_sprites_at_point((self.world_x,self.world_y), self.wall_list)
                    for sprite in hovered_sprites:
                        sprite.remove_from_sprite_lists()
                    self.wall_tiles.remove(self.clicked_tile)


    def on_mouse_motion(self, x, y, dx, dy):
        self.mouse_x = x
        self.mouse_y = y
        self.cursor_sprite.center_x = x
        self.cursor_sprite.center_y = y
        #hovered_buttons = arcade.get_sprites_at_point((x,y), self.restart_rect)
        #if hovered_buttons:
            #print("RESTART")

    def pixel_to_tile(self, pixel_x, pixel_y, tile_width, tile_height, map_height):
        """
        Convert Arcade pixel coordinates to Tiled tile coordinates.
        """
        tile_x = int(pixel_x // tile_width)
        tile_y = int(map_height - (pixel_y // tile_height) - 1)
        return tile_x, tile_y


    def spawn_fire(self, x, y):
        fire = arcade.Sprite()
        fire.texture = self.fire_sprites[random.randrange(0, len(self.fire_sprites))]
        fire.scale = random.randrange(0, 7)
        fire.center_x = x + random.randrange(-15 * TILE_SCALING, 15 * TILE_SCALING)
        fire.center_y = y + random.randrange(-15 * TILE_SCALING, 15 * TILE_SCALING)
        self.fire_list.append(fire)
        colliding_bigpuddle = arcade.check_for_collision_with_list(fire, self.puddle_list)
        if colliding_bigpuddle:
            self.lost_game = True
        #if len(self.small_pud_list) > 0:
            #print(self.small_pud_list)
            #colliding_smallpuddle = arcade.check_for_collision_with_list(fire, self.small_pud_list)


    def spread_fire(self):
        self.fire_spread_time = random.random() * 1
        if len(self.tiles_on_fire) > 0:
            tiles_to_add = []
            for tile in self.tiles_on_fire:
                up = (tile[0], tile[1] - 1)
                down = (tile[0], tile[1] + 1)
                left = (tile[0] - 1, tile[1])
                right = (tile[0] + 1, tile[1])
                tiles_to_add += up, down, left, right
                for item in tiles_to_add:
                    if item in self.slowed_fire_tiles.values():
                        tiles_to_add.remove(item)
                        if item not in self.puddles_touching_fire:
                            self.puddles_touching_fire.append(item)
                            
            for tile in tiles_to_add:
                if tile not in self.tiles_on_fire and tile in self.wall_tiles:
                    self.tiles_on_fire.append(tile)
                    self.spawn_fire(32 * TILE_SCALING * (tile[0] + 0.5) , 32 * TILE_SCALING * (MAP_HEIGHT - 0.5 - tile[1]))

            
    def spawn_water(self, x, y):
        water = arcade.Sprite()
        water.texture = self.small_pud_sprites[random.randrange(0, 4) * 10 + 2]
        water.scale = TILE_SCALING
        water.center_x = x
        water.center_y = y
        self.small_pud_list.append(water)
        self.slowed_fire_tiles[water] = self.clicked_tile
        self.slowed_fire_timer[self.clicked_tile] = 3.0
            
            
    def game_over(self):
        self.lost_game = False
        
        self.fire_list.clear(deep=True)
        self.tiles_on_fire.clear()
        self.time_left = TIME_LIMIT
        self.used_fire = False
    
    
    def change_cursor(self):
        self.world_x = self.mouse_x - SCREEN_WIDTH/2 + self.player_sprite.position[0]
        self.world_y = self.mouse_y - SCREEN_HEIGHT/2 + self.player_sprite.position[1]        
        if self.current_item > 0:
            self.clicked_tile = self.pixel_to_tile(self.world_x, self.world_y, 32 * TILE_SCALING, 32 * TILE_SCALING, MAP_HEIGHT)
            if self.current_item == 1:
                hovered_sprites = arcade.get_sprites_at_point((self.world_x,self.world_y), self.puddle_list)
                hovered_sprites += arcade.get_sprites_at_point((self.world_x,self.world_y), self.small_pud_list)
                if hovered_sprites:
                    self.cursor_sprite.alpha = 255
                    self.cursor_sprite.scale = 2
                else:
                    self.cursor_sprite.alpha = 100
                    self.cursor_sprite.scale = 1                    
            elif self.current_item == 2 and self.clicked_tile in self.wall_tiles and self.water_level >= 1:
                self.cursor_sprite.alpha = 255
                self.cursor_sprite.scale = 2
            elif self.current_item == 3 and self.clicked_tile in self.wall_tiles:
                self.cursor_sprite.alpha = 255
                self.cursor_sprite.scale = 2
            elif self.current_item == 4 and self.clicked_tile in self.wall_tiles:
                self.cursor_sprite.alpha = 255
                self.cursor_sprite.scale = 2
            else:
                self.cursor_sprite.alpha = 100
                self.cursor_sprite.scale = 1
        else:
            self.cursor_sprite.alpha = 255
            self.cursor_sprite.scale = 1


def main():
    """Main method """
    window = MyGame()
    window.setup()
    arcade.run()
    
    
if __name__ == "__main__":
    main()